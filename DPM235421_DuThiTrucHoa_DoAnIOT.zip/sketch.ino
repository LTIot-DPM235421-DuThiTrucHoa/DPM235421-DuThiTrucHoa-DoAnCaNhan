#define BLYNK_TEMPLATE_ID   "TMPL6Mb95d1UU"
#define BLYNK_TEMPLATE_NAME "Smart Trash Can"
#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <ESP32Servo.h>

// --- Cấu hình thông tin mạng và Blynk ---
char auth[] = "6K8kD5b8orjf370zGPQaGioNWt5Nv3Qw";
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// --- Khai báo chân kết nối phần cứng (Pins) ---
// Cảm biến 1: Mặt trước (Phát hiện người xả rác)
const int TRIG_PIN_FRONT = 5;
const int ECHO_PIN_FRONT = 18;

// Cảm biến 2: Mặt trong / Dưới nắp (Đo độ đầy rác)
const int TRIG_PIN_INSIDE = 14;
const int ECHO_PIN_INSIDE = 12;

// Chấp hành & Đèn chỉ thị / Cảnh báo
const int SERVO_PIN = 13;        // Tín hiệu PWM điều khiển Servo
const int RED_LED_PIN = 4;       // LED Đỏ báo rác đầy / Khóa nắp
const int GREEN_LED_PIN = 2;    // LED Xanh báo trạng thái sẵn sàng
const int BUZZER_PIN = 15;        // Còi chíp cảnh báo

Servo trashServo;

// --- Biến quản lý trạng thái hệ thống ---
bool isBinOpen = false;         // Trạng thái nắp thùng rác (Mở/Đóng)
bool isBinFull = false;         // Trạng thái thùng rác (Đầy/Chưa đầy)
bool notifiedFull = false;      // Cờ đánh dấu đã gửi thông báo Blynk chưa
bool manualOverride = false;    // Biến cờ khóa chế độ tự động khi mở từ Blynk App

// --- Biến thời gian không chặn (Non-blocking millis) ---
unsigned long previousMillis = 0;
const long interval = 200;      // Chu kỳ quét cảm biến (200ms / lần)

unsigned long servoOpenTime = 0; // Thời điểm cập nhật mở nắp
const long servoDuration = 3000; // Thời gian trễ đóng nắp sau khi người dùng rời đi (3 giây)

// --- Biến quản lý kết nối Blynk định kỳ ---
unsigned long lastBlynkCheck = 0;
const long blynkCheckInterval = 10000; // Kiểm tra lại kết nối Blynk mỗi 10 giây

// --- Điều khiển mở nắp cưỡng bức từ xa qua app Blynk (Nút V1) dành cho nhân viên vệ sinh ---
BLYNK_WRITE(V1) {
  int pinValue = param.asInt(); // Nhận giá trị 0 hoặc 1 từ nút Switch Blynk
  Serial.print("Trạng thái nút Switch V1: ");
  Serial.println(pinValue);

  if (pinValue == 1) {
    Serial.println("-> LỆNH MỞ NẮP TỪ BLYNK (GIỮ MỞ ĐỂ THU GOM)!");
    manualOverride = true;     // Bật cờ khóa: Chặn hoàn toàn vòng lặp tự động đóng/mở
    trashServo.write(90);      // Xoay 90 độ mở nắp cố định
    isBinOpen = true;
  } 
  else {
    Serial.println("-> LỆNH ĐÓNG NẮP TỪ BLYNK!");
    manualOverride = false;    // Tắt cờ khóa: Trả về hoạt động tự động bình thường
    trashServo.write(0);       // Trả về 0 độ đóng nắp
    isBinOpen = false;
  }
}

void setup() {
  Serial.begin(115200);

  // Cấu hình GPIO cho 2 cảm biến siêu âm
  pinMode(TRIG_PIN_FRONT, OUTPUT);
  pinMode(ECHO_PIN_FRONT, INPUT);
  pinMode(TRIG_PIN_INSIDE, OUTPUT);
  pinMode(ECHO_PIN_INSIDE, INPUT);

  // Cấu hình GPIO cho LED Đỏ, LED Xanh và Còi
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Ban đầu: Bật LED Xanh (Sẵn sàng), Tắt LED Đỏ & Còi
  digitalWrite(GREEN_LED_PIN, HIGH);
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);

  // Khởi tạo động cơ Servo về vị trí đóng (0 độ)
  trashServo.attach(SERVO_PIN, 500, 2400);
  trashServo.write(0);

  // Kết nối Wi-Fi và Blynk
  Serial.print("Đang kết nối Wi-Fi");
  WiFi.begin(ssid, pass);
  unsigned long startAttemptTime = millis();
  
  // Chờ kết nối Wi-Fi tối đa 10 giây (cho phép chạy Offline nếu mất mạng)
  while (WiFi.status() != WL_CONNECTED && millis() - startAttemptTime < 10000) {
    delay(500);
    Serial.print(".");
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nĐã kết nối Wi-Fi thành công!");
    Blynk.config(auth);
  } else {
    Serial.println("\nKhông kết nối được Wi-Fi, chuyển sang chế độ vận hành cục bộ (Offline Mode).");
  }
}

void loop() {
  // Duy trì kết nối Blynk thông minh (Không chặn vòng lặp)
  if (WiFi.status() == WL_CONNECTED) {
    if (Blynk.connected()) {
      Blynk.run();
    } else {
      unsigned long currentMillis = millis();
      if (currentMillis - lastBlynkCheck >= blynkCheckInterval) {
        lastBlynkCheck = currentMillis;
        Serial.println("Đang thử kết nối lại với Blynk Cloud...");
        Blynk.connect(1000); // Thử kết nối trong 1 giây
      }
    }
  }

  // NẾU ĐANG BẬT NÚT MỞ CƯỠNG BỨC TRÊN BLYNK -> KHÓA HẲN VÒNG LẶP ĐỂ THU GOM RÁC
  if (manualOverride) {
    return;
  }

  // Quét dữ liệu định kỳ bằng millis()
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // Đo khoảng cách từ 2 cảm biến siêu âm
    float distanceInside = measureDistance(TRIG_PIN_INSIDE, ECHO_PIN_INSIDE);
    float distanceFront  = measureDistance(TRIG_PIN_FRONT, ECHO_PIN_FRONT);

    // Gửi giá trị mức độ đầy rác lên Virtual Pin V0 của Blynk
    if (Blynk.connected()) {
      Blynk.virtualWrite(V0, distanceInside);
    }

    // ===========================================================
    // LOGIC 1: ĐO MỨC RÁC ĐẦY & KHÓA NẮP CHỐNG NHỒI NHÉT
    // ===========================================================
    if (distanceInside > 0 && distanceInside < 5.0) {
      isBinFull = true;
      digitalWrite(RED_LED_PIN, HIGH);   // Bật LED Đỏ báo đầy / khóa nắp
      digitalWrite(GREEN_LED_PIN, LOW);  // Tắt LED Xanh

      // --- GỬI THÔNG BÁO TỚI BLYNK (Chỉ gửi 1 lần khi bắt đầu đầy) ---
      if (!notifiedFull) {
        if (Blynk.connected()) {
          Blynk.logEvent("trash_full", "CẢNH BÁO: Thùng rác đã đầy (>85%), vui lòng thu gom!");
          Serial.println("Đã gửi thông báo rác đầy qua Blynk IoT!");
        }
        notifiedFull = true; // Đánh dấu đã gửi để không bị gửi liên tục
      }

      // Cảnh báo tại chỗ: Nếu có người bước lại gần (nhỏ hơn 30cm), còi chỉ phát tiếng bíp ngắn
      if (distanceFront > 0 && distanceFront <= 30.0) {
        digitalWrite(BUZZER_PIN, HIGH);
        delay(150); // Phát tiếng bíp ngắn 150ms
        digitalWrite(BUZZER_PIN, LOW);
      } else {
        digitalWrite(BUZZER_PIN, LOW);
      }
    } 
    else {
      isBinFull = false;
      digitalWrite(RED_LED_PIN, LOW);    // Tắt LED Đỏ
      digitalWrite(GREEN_LED_PIN, HIGH); // Bật LED Xanh duy trì trạng thái sẵn sàng
      digitalWrite(BUZZER_PIN, LOW);
    }

    // ===========================================================
    // LOGIC 2: NHẬN BIẾT NGƯỜI XẢ RÁC & GIA HẠN GIỮ NẮP MỞ LINH HOẠT
    // ===========================================================
    // Chỉ tự động mở nắp khi rác CHƯA ĐẦY (isBinFull == false)
    if (!isBinFull) {
      // Phát hiện người trong phạm vi nhỏ hơn 30 cm
      if (distanceFront > 0 && distanceFront <= 30.0) {
        if (!isBinOpen) {
          openTrashBin(); // Mở nắp nếu nắp đang đóng
        } else {
          servoOpenTime = millis(); // GIA HẠN thời gian mở nắp chừng nào người dùng còn đứng xả rác
        }
      }
    }
  }

  // =============================================================
  // LOGIC 3: ĐẾM TRỄ ĐÓNG NẮP KHI NGƯỜI DÙNG ĐÃ RỜI ĐI
  // =============================================================
  if (isBinOpen && (millis() - servoOpenTime >= servoDuration)) {
    closeTrashBin();
  }
}

// --- Hàm đo khoảng cách bằng cảm biến siêu âm HC-SR04 ---
float measureDistance(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000); // Timeout 30ms để tránh treo vi điều khiển
  if (duration == 0) return 999.0;               // Trả về giá trị vô cực nếu lỗi sóng

  float distance = duration * 0.034 / 2;
  return distance;
}

// --- Hàm mở nắp thùng rác ---
void openTrashBin() {
  trashServo.write(90);       // Xoay Servo góc 90 độ mở nắp
  isBinOpen = true;
  servoOpenTime = millis();   // Ghi lại mốc thời điểm mở nắp
  Serial.println("Đã mở nắp thùng rác.");
}

// --- Hàm đóng nắp thùng rác ---
void closeTrashBin() {
  trashServo.write(0);        // Đưa Servo về góc 0 độ đóng nắp
  isBinOpen = false;
  Serial.println("Đã đóng nắp thùng rác.");
}